window.onload = function () {
  const script = document.createElement('script');
  script.src = 'https://cdn.jsdelivr.net/npm/tabletop@1.5.1/tabletop.min.js';
  document.head.appendChild(script);

  script.onload = () => {
    Tabletop.init({
      key: 'https://script.google.com/macros/s/AKfycbzA_SQQLGRGFnFqtRXJBGv3sDM2B8oPdKbIp6p3MnaiDcI6gc85BM9Oc5yh_ndrSA3i5Q/exec',
      simpleSheet: true,
      callback: function (data) {
        const tableHead = document.querySelector('#data-table thead');
        const tableBody = document.querySelector('#data-table tbody');

        const headers = Object.keys(data[0]);
        const headRow = document.createElement('tr');
        headers.forEach(header => {
          const th = document.createElement('th');
          th.textContent = header;
          headRow.appendChild(th);
        });
        tableHead.appendChild(headRow);

        data.forEach(row => {
          const tr = document.createElement('tr');
          headers.forEach(header => {
            const td = document.createElement('td');
            td.textContent = row[header];
            tr.appendChild(td);
          });
          tableBody.appendChild(tr);
        });

        // Barre de recherche
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', function () {
          const filter = searchInput.value.toLowerCase();
          const rows = tableBody.querySelectorAll('tr');
          rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
          });
        });
      }
    });
  };
};